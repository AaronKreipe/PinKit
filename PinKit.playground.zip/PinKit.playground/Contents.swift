import UIKit
import PlaygroundSupport

//: # PinKit Examples

/*:
 Ignore me!  I'm just a simple function to create a colored view with a label in it's center.\
 The real stuff starts below.
 */
func generateView(_ title: String, color: UIColor)->UIView{
    let view = UIView()
    view.backgroundColor = color
    view.translatesAutoresizingMaskIntoConstraints = false
    let label = UILabel()
    label.text = title
    label.textAlignment = .center
    label.translatesAutoresizingMaskIntoConstraints = false
    view.addSubview(label)
    label.pinEdges(to: view)
    return view
}

//: Display a blank `UIViewController`
let vc = UIViewController()
vc.view.backgroundColor = .brown
PlaygroundPage.current.liveView = vc

//: Make a `backgroundView` the full size of the view controller's `view`
let backgroundView = generateView("background", color: .blue)
vc.view.addSubview(backgroundView)
backgroundView.pinEdges(to: vc.view)

//: Add a `windowView` to the the `backgroundView`
let windowView = generateView("window", color: .white)
backgroundView.addSubview(windowView)
//: Set some wild constraints
[windowView.topAnchor |=| backgroundView.topAnchor + 10,
 windowView.leadingAnchor |=| backgroundView.leadingAnchor + 20,
 windowView.bottomAnchor |=| backgroundView.bottomAnchor - 50,
 windowView.widthAnchor |<=| backgroundView.widthAnchor / 2,
 windowView.widthAnchor |>=| backgroundView.widthAnchor / 3 + 10]
    .activate()

//: Create 2 more views and put them in the top half (-20) of the `windowView` with equal widths
let viewA = generateView("A", color: .orange)
let viewB = generateView("B", color: .purple)

windowView.addSubview(viewA)
windowView.addSubview(viewB)

[viewA.topAnchor |=| windowView.topAnchor,
 viewA.leadingAnchor |=| windowView.leadingAnchor,
 viewA.widthAnchor |=| windowView.widthAnchor/2,
 viewA.heightAnchor |=| windowView.heightAnchor/2 - 20,
 
 viewB.topAnchor |=| viewA.topAnchor,
 viewB.leadingAnchor |=| viewA.trailingAnchor,
 viewB.widthAnchor |=| viewA.widthAnchor,
 viewB.heightAnchor |=| viewA.heightAnchor].activate()

//: Create another view and use system spacing (with some modifications) to fit it in the right side of the `backgroundView`.
let viewC = generateView("systemSpacing", color: UIColor.green.withAlphaComponent(0.5))
backgroundView.addSubview(viewC)

[viewC.topAnchor |=|~ backgroundView.topAnchor * 2,
viewC.leadingAnchor |=|~ windowView.trailingAnchor/3,
backgroundView.trailingAnchor |<=|~ viewC.trailingAnchor * 3,
backgroundView.bottomAnchor |=|~ viewC.bottomAnchor * 0.5].activate()

/*:
 - Bug:\
 On my Mac in a playground the constraints do not apply immediately without the two lines below.  On my iPad it works without them.
 ### `¯\_(ツ)_/¯`
 */
#if arch(x86_64)
vc.view.setNeedsLayout()
vc.view.layoutIfNeeded()
#endif
 
/*:
 # Q & A
 Q: Do we really need another AutoLayout framework?\
 A: No!  This isn't one either!  It's just an easier way to use what Apple gives us.\
 \
 Q: It's not working!\
 A: Make sure you are setting `translatesAutoresizingMaskIntoConstraints` to `false` on the view you are trying to constrain.  Also try calling `setNeedsLayout()` and`layoutIfNeeded()` on the containing view.\
 \
 Q: It's crashing!\
 A: Your constraints are probably conflicting somehow.  Look for messages in the console.\
 \
 Q: OK, this is much easier for adding constraints, but how do I remove them?\
 A: use `UIView.removeConstraints()` just like you used to, or remove a whole array of constraints with `.deactivate()`.\
 \
 Q: What versions of Swift does PinKit work with?\
 A: It has been tested in Swift 4.1.2, and Swift 4.2, and may work in others.\
\
 Q: What do I have to do when apple renames all of the `.constraint*SystemSpacing*()` functions in Swift 4.2?\
 A: Nothing.🎉  I used conditional compilation flags to support both.\
 \
 Q: Where are all of the blank XCTest files?\
 A: This was built and tested in an iPad playground.  Well there wasn't much to test really, it's all just a bunch of syntactic sugar.\
 \
 Q: Are you crazy?\
 A: Maybe a little🤷‍♂️\
 \
 Q: Do you do this for a living?\
 A: Hopefully I will soon! You can buy [my apps in the iOS AppStore](https://itunes.com/AaronKreipe) to help!\
 \
 Q: Are you using this in your apps?\
 A: Not yet, I prefer to use storyboards, but I use it in my playgrounds.
 */








